Samantha Xiong (xion1884)
How to Compile: Type "javac Battleboats.java" into terminal
How to Run:
    Type "java Main" into terminal.
    Follow Directions printed to terminal.
    When typing in coordinates, please type "x,y" with no spaces.
Any known bugs/defects: There are no known bug or defects. When the game ends, the total amount of canon shots includes the shots with the missile.